<?php

namespace phpDocumentor\Descriptor\Interfaces;

interface TypeInterface
{
}
